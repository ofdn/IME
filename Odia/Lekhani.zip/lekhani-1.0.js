KeymanWeb.KR(new Keyboard_lekhani());
function Keyboard_lekhani()
{
  this.KI="Keyboard_lekhani";
  this.KN="Lekhani";
  this.KV={F:' 1em "Arial"',K102:0,BK:new Array("","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","")};this.KDU=1;
  this.KH='Lekhani is a phonetic Odia input layout. Lekhani draws inspiration from "Oriya phonetic typing on Ubuntu" and "Oriya - QUERTY" on Mac. It was initiated in 2011 and implemented on Mediawiki during 2012.  Features      Lekhani is a phonetic input layout, so individual key input gives Odia characters without a halanta     Halanta ( ୍ ) is normally used to type conjuncts (ଯୁକ୍ତାଷର). You need to type z to get ୍. For example type କ ୍ (Type z)ତ to get କ୍ତ.     Most used conjuncts (e.g. ଙ୍କ, ଙ୍ଖ, ଙ୍ଗ, ମ୍ପ, ଞ୍ଜ, ମ୍ବ) could be written by joining two characters with a halanta (z is used to type halanta)  Vowels ଅ 	ଆ 	ଇ 	ଈ 	ଉ 	ଊ a 	aa 	i 	I 	u 	U ଏ 	ଐ 	ଓ 	ଔ 	ଋ e 	ai 	o 	au 	R   Consonants କ 	ଖ 	ଗ 	ଘ 	ଙ k 	kh 	g 	gh 	NG ଚ 	ଛ 	ଜ 	ଝ 	ଞ c 	Ch 	j 	jh 	Ng ଟ 	ଠ 	ଡ 	ଢ 	ଣ T 	Th 	D 	Dh 	N ତ 	ଥ 	ଦ 	ଧ 	ନ t 	th 	d 	dh 	n ପ 	ଫ 	ବ 	ଭ 	ମ p 	ph/F 	b 	bh 	m ଯ 	ର 	ଲ 	ୱ 	ଶ y 	r 	l 	w 	S ଷ 	ସ 	ହ 	ଳ 	କ୍ଷ X 	s 	h 	L 	x ଜ୍ଞ 	ଡ଼ 	ଢ଼ 		 Z 	q 	Q 		  Matra କା 	କି 	କୀ 	କେ 	କୈ 	କୁ 	କୂ 	କୋ 	କୌ ka 	ki 	kI 	ke 	kE 	ku 	kU 	ko 	kou ୍ (ହଳନ୍ତ) 	କ୍ର 	କ୍ରା 	କ୍ରି 	କ୍ରେ 	କ୍ରୋ 	କ୍ରୀ 	କ୍ରୌ 	କ୍ରୈ z 	kzr 	kzra 	kzri 	kzre 	kzro 	kzrI 	kzrou 	kzrE Conjuncts କ୍କ kk 	ଚ୍ଚ cc 	ଚ୍ଛ cch 	ଜ୍ଜ jj 	ଟ୍ଟ TT 	ଡ୍ଡ DD 	ଣ୍ଣ NzN 	ତ୍ତ tt 	ଦ୍ଦ dd 	ନ୍ନ nn 	ପ୍ପ pp 	ଭ୍ଭ bhzbh 	ମ୍ମ mzm 	ଲ୍ଲ ll ଜ୍ଝ jzjh 	ତ୍ଥ tzth 	ଦ୍ଧ dzdh 	ବ୍ଦ dzdh 	ବ୍ଧ bzdh 	କ୍ଟ 	କ୍ତ 	କ୍ଥ 	କ୍ନ 	କ୍ମ 	କ୍ର 	କ୍ଳ 	କ୍ଲ 	କ୍ୱ କ୍ସ kzs 	ଗ୍ଣ gzm 	ଗ୍ର gzr 	ଗ୍ଳ gzL 	ଗ୍ଳ gzL 	ଗ୍ୱ gw 	ଘ୍ନ ghzn 	ଘ୍ର ghzr 	ଙ୍କ nk 	ଙ୍ଖ nkh 	ଙ୍ଗ ng 	ଙ୍ଘ ngh 	ଚ୍ର czr 	ଜ୍ର jzr ଞ୍ଚ nc 	ଞ୍ଛ nch 	ଞ୍ଜ nj 	ଞ୍ଝ njh   Test examples  Use halanta ୍ to join two characters to write conjuncts (Odia: ଯୁକ୍ତାକ୍ଷର or Juktakhyara) z      ସ‌ହର= s_hr     ସ୍ୱର୍ଣ୍ଣ = swrzNzN     ପ୍ରତି = p zrti     ପ୍ରୌଢ଼ = pzrouQ     କୃତ୍ୟ = kRtY     ଟାଇପ୍‌ର = Taipz_r      Resources: 1. Help page in English: https://www.mediawiki.org/wiki/Help:Extension:UniversalLanguageSelector/Input_methods/or-lekhani 2. Help page in Odia: https://or.wikipedia.org/s/oup ';
  this.KM=0;
  this.KBVER="1.0";
  this.KVER="9.0.526.0";
  this.gs=function(t,e) {
    return this.g_main(t,e);
  };
  this.g_main=function(t,e) {
    var k=KeymanWeb,r=0,m=0;
    if(k.KKM(e,16384,48)) {   // Line 17
      r=m=1;
      k.KO(0,t,"୦");
    }
    else if(k.KKM(e,16384,49)) {   // Line 26
      r=m=1;
      k.KO(0,t,"୧");
    }
    else if(k.KKM(e,16384,50)) {   // Line 25
      r=m=1;
      k.KO(0,t,"୨");
    }
    else if(k.KKM(e,16384,51)) {   // Line 24
      r=m=1;
      k.KO(0,t,"୩");
    }
    else if(k.KKM(e,16384,52)) {   // Line 23
      r=m=1;
      k.KO(0,t,"୪");
    }
    else if(k.KKM(e,16384,53)) {   // Line 22
      r=m=1;
      k.KO(0,t,"୫");
    }
    else if(k.KKM(e,16384,54)) {   // Line 21
      r=m=1;
      k.KO(0,t,"୬");
    }
    else if(k.KKM(e,16384,55)) {   // Line 20
      r=m=1;
      k.KO(0,t,"୭");
    }
    else if(k.KKM(e,16384,56)) {   // Line 19
      r=m=1;
      k.KO(0,t,"୮");
    }
    else if(k.KKM(e,16384,57)) {   // Line 18
      r=m=1;
      k.KO(0,t,"୯");
    }
    else if(k.KKM(e,16384,65)) {   // Line 41
      r=m=1;
      k.KO(0,t,"ଅ");
    }
    else if(k.KKM(e,16400,65)) {   // Line 68
      r=m=1;
      k.KO(0,t,"ଆ");
    }
    else if(k.KKM(e,16384,66)) {   // Line 29
      r=m=1;
      k.KO(0,t,"ବ");
    }
    else if(k.KKM(e,16400,66)) {   // Line 60
      r=m=1;
      k.KO(0,t,"ବ");
    }
    else if(k.KKM(e,16384,67)) {   // Line 31
      r=m=1;
      k.KO(0,t,"ଚ");
    }
    else if(k.KKM(e,16400,67)) {   // Line 73
      r=m=1;
      k.KO(0,t,"ଛ");
    }
    else if(k.KKM(e,16384,68)) {   // Line 39
      r=m=1;
      k.KO(0,t,"ଦ");
    }
    else if(k.KKM(e,16400,68)) {   // Line 63
      r=m=1;
      k.KO(0,t,"ଡ");
    }
    else if(k.KKM(e,16384,69)) {   // Line 49
      r=m=1;
      k.KO(0,t,"ଏ");
    }
    else if(k.KKM(e,16400,69)) {   // Line 76
      r=m=1;
      k.KO(0,t,"ଐ");
    }
    else if(k.KKM(e,16384,70)) {   // Line 38
      r=m=1;
      k.KO(0,t,"ଫ");
    }
    else if(k.KKM(e,16400,70)) {   // Line 61
      r=m=1;
      k.KO(0,t,"ଫ");
    }
    else if(k.KKM(e,16384,71)) {   // Line 37
      r=m=1;
      k.KO(0,t,"ଗ");
    }
    else if(k.KKM(e,16400,71)) {   // Line 74
      r=m=1;
      k.KO(0,t,"ଘ");
    }
    else if(k.KKM(e,16384,72)) {   // Line 36
      r=m=1;
      k.KO(0,t,"ହ");
    }
    else if(k.KKM(e,16400,72)) {   // Line 71
      r=m=1;
      k.KO(0,t,"ଃ");
    }
    else if(k.KKM(e,16384,73)) {   // Line 44
      r=m=1;
      k.KO(0,t,"ଇ");
    }
    else if(k.KKM(e,16400,73)) {   // Line 67
      r=m=1;
      k.KO(0,t,"ଈ");
    }
    else if(k.KKM(e,16384,74)) {   // Line 35
      r=m=1;
      k.KO(0,t,"ଜ");
    }
    else if(k.KKM(e,16400,74)) {   // Line 72
      r=m=1;
      k.KO(0,t,"ଝ");
    }
    else if(k.KKM(e,16400,75)) {   // Line 77
      r=m=1;
      k.KO(0,t,"ଖ");
    }
    else if(k.KKM(e,16384,75)) {   // Line 78
      r=m=1;
      k.KO(0,t,"କ");
    }
    else if(k.KKM(e,16384,76)) {   // Line 34
      r=m=1;
      k.KO(0,t,"ଲ");
    }
    else if(k.KKM(e,16400,76)) {   // Line 52
      r=m=1;
      k.KO(0,t,"ଳ");
    }
    else if(k.KKM(e,16384,77)) {   // Line 27
      r=m=1;
      k.KO(0,t,"ମ");
    }
    else if(k.KKM(e,16400,77)) {   // Line 70
      r=m=1;
      k.KO(0,t,"ଂ");
    }
    else if(k.KKM(e,16384,78)) {   // Line 28
      r=m=1;
      k.KO(0,t,"ନ");
    }
    else if(k.KKM(e,16400,78)) {   // Line 62
      r=m=1;
      k.KO(0,t,"ଣ");
    }
    else if(k.KKM(e,16384,79)) {   // Line 43
      r=m=1;
      k.KO(0,t,"ଓ");
    }
    else if(k.KKM(e,16400,79)) {   // Line 75
      r=m=1;
      k.KO(0,t,"ଔ");
    }
    else if(k.KKM(e,16384,80)) {   // Line 42
      r=m=1;
      k.KO(0,t,"ପ");
    }
    else if(k.KKM(e,16400,80)) {   // Line 58
      r=m=1;
      k.KO(0,t,"ଫ");
    }
    else if(k.KKM(e,16384,81)) {   // Line 51
      r=m=1;
      k.KO(0,t,"ଡ଼");
    }
    else if(k.KKM(e,16400,81)) {   // Line 57
      r=m=1;
      k.KO(0,t,"ଢ଼");
    }
    else if(k.KKM(e,16384,82)) {   // Line 48
      r=m=1;
      k.KO(0,t,"ର");
    }
    else if(k.KKM(e,16400,82)) {   // Line 65
      r=m=1;
      k.KO(0,t,"ଋ");
    }
    else if(k.KKM(e,16384,83)) {   // Line 40
      r=m=1;
      k.KO(0,t,"ସ");
    }
    else if(k.KKM(e,16400,83)) {   // Line 59
      r=m=1;
      k.KO(0,t,"ଶ");
    }
    else if(k.KKM(e,16384,84)) {   // Line 47
      r=m=1;
      k.KO(0,t,"ତ");
    }
    else if(k.KKM(e,16400,84)) {   // Line 64
      r=m=1;
      k.KO(0,t,"ଟ");
    }
    else if(k.KKM(e,16384,85)) {   // Line 45
      r=m=1;
      k.KO(0,t,"ଉ");
    }
    else if(k.KKM(e,16400,85)) {   // Line 66
      r=m=1;
      k.KO(0,t,"ଊ");
    }
    else if(k.KKM(e,16384,86)) {   // Line 30
      r=m=1;
      k.KO(0,t,"ୱ");
    }
    else if(k.KKM(e,16400,86)) {   // Line 54
      r=m=1;
      k.KO(0,t,"ୱ");
    }
    else if(k.KKM(e,16384,87)) {   // Line 50
      r=m=1;
      k.KO(0,t,"ୱ");
    }
    else if(k.KKM(e,16400,87)) {   // Line 56
      r=m=1;
      k.KO(0,t,"ୱ");
    }
    else if(k.KKM(e,16384,88)) {   // Line 32
      r=m=1;
      k.KO(0,t,"କ୍ଷ");
    }
    else if(k.KKM(e,16400,88)) {   // Line 69
      r=m=1;
      k.KO(0,t,"ଁ");
    }
    else if(k.KKM(e,16384,89)) {   // Line 46
      r=m=1;
      k.KO(0,t,"ଯ");
    }
    else if(k.KKM(e,16400,89)) {   // Line 53
      r=m=1;
      k.KO(0,t,"ୟ");
    }
    else if(k.KKM(e,16384,90)) {   // Line 33
      r=m=1;
      k.KO(0,t,"୍");
    }
    else if(k.KKM(e,16400,90)) {   // Line 55
      r=m=1;
      k.KO(0,t,"ଜ୍ଞ");
    }
    return r;
  };
}
